<?php 

include 'header.php'; ?>
<?php

function getProjects($filter = '')
{
    global $con;
    $query = "SELECT * FROM `projects`";
    if ($filter) {
        $query .= " WHERE `status` = '$filter'";
    }
    $query .= " ORDER BY `id` DESC";
    return mysqli_query($con, $query);
}

$filter = isset($_GET['filter']) ? $_GET['filter'] : '';
$projects = getProjects($filter);
?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Projects</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Projects</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Projects Section -->
    <section id="projects" class="projects section" style="background-color: black;color: white">

      <div class="container">

    <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">

        <ul class="portfolio-filters isotope-filters" data-aos="fade-up" data-aos-delay="100">
            <li><a href="?filter=" class="<?php echo $filter == '' ? 'filter-active' : ''; ?>">All</a></li>
            <li><a href="?filter=BOOKING" class="<?php echo $filter == 'BOOKING' ? 'filter-active' : ''; ?>">Booking</a></li>
            <li><a href="?filter=Ongoing" class="<?php echo $filter == 'Ongoing' ? 'filter-active' : ''; ?>">Ongoing</a></li>
            <li><a href="?filter=Accomplish" class="<?php echo $filter == 'Accomplish' ? 'filter-active' : ''; ?>">Accomplish</a></li>
                    </ul><!-- End Portfolio Filters -->

        <div class="row gy-4 isotope-container" data-aos="fade-up" data-aos-delay="200">
            <?php while ($data = mysqli_fetch_assoc($projects)) : ?>
                <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-<?php echo strtolower($data['status']); ?>">
                    <div class="portfolio-content h-100">
                        <img src="Admin_panel/projectimages/<?php echo $data['image']; ?>" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><?php echo $data['title']; ?></h4>
                            <p><?php echo $data['description']; ?></p>
                            <a href="Admin_panel/projectimages/<?php echo $data['image']; ?>" title="<?php echo $data['title']; ?>" data-gallery="portfolio-gallery-<?php echo strtolower($data['status']); ?>" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                            <a href="project-details.php?id=<?php echo $data['id']; ?>" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a>
                        </div>
                    </div>
                </div><!-- End Portfolio Item -->
            <?php endwhile; ?>
        </div><!-- End Portfolio Container -->

    </div>


    </section><!-- /Projects Section -->

  </main>

  <?php include 'footer.php'; ?>