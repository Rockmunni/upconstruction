-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2024 at 09:45 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thecrown`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'crownbuiliders2025@gmail.com', 'thecrown@1908');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`) VALUES
(1, 'muniba ', 'muniba@gmail.com', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `phone`, `subject`, `message`) VALUES
(1, 'muniba ', '12345678900', '', 'hello'),
(2, '', '12345678900', '', 'hello'),
(3, '', '12345678900', '', 'hello'),
(4, '', '12345678900', '', 'hello'),
(5, '', '12345678900', '', 'hello'),
(6, '', '12345678900', '', 'hello'),
(7, '', '12345678900', '', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `image_02` varchar(100) NOT NULL,
  `image_03` varchar(100) NOT NULL,
  `image_04` varchar(100) NOT NULL,
  `image_05` varchar(100) NOT NULL,
  `image_06` varchar(100) NOT NULL,
  `image_07` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `image`, `image_02`, `image_03`, `image_04`, `image_05`, `image_06`, `image_07`, `title`, `description`, `status`) VALUES
(2, '6.png', '2.png', '1.png', '4.png', 'crown 2.png', 'the crow.png', 'the crow.png', '', '', 'accomplish'),
(3, '3.png', '550 crownn.png', 'the crow.png', 'the crow.png', 'the crow.png', 'the crow.png', 'the crow.png', 'proejct two', 'The crown Builiders', 'accomplish'),
(4, '2.png', 'crown 2.png', 'crown 2.png', 'crown 2.png', 'the crow.png', 'crown 2.png', 'crown 2.png', 'project three', 'The crown BuilidersThe crown Builiders', 'ongoing'),
(5, '3.png', 'crown 2.png', 'the crow.png', 'the crow.png', 'crown 2.png', 'the crow.png', 'the crow.png', 'project four', 'The crown Builiders', 'booking'),
(6, '1.png', 'the crow.png\'', 'crown 2.png', 'the crow.png', 'the crow.png', 'the crow.png', '', 'hello', 'heelo', 'ongoing'),
(7, '5.png', 'crown 2.png', 'crown 2.png', 'crown 2.png', 'crown 2.png', 'crown 2.png', 'crown 2.png', 'abc', 'abc', 'booking'),
(8, '550 crownn.png', '550 crownn.png', '550 crownn.png', '', '', '', '', '', 'The crown Builiders', ''),
(9, '550 crownn.png', '2.png', '2.png', '3.png', '5.png', '', '', '', 'The crown Builiders', 'booking'),
(12, '1.png', '1.png', '4.png', '3.png', '5.png', '', '', '', 'The crown Builiders', 'booking'),
(13, '2.png', '1.png', '3.png', '3.png', '1.png', '5.png', '550 crownn.png', '', 'The crown Builiders', 'Select the Proejct Status'),
(14, '3.png', '550 crownn.png', '6.png', '1.png', '', '', '', 'select ', 'selectinggg', 'ongoing');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `image`, `title`, `description`) VALUES
(1, '11.png', 'Outstanding Construction Services  ', 'We provide complete remodeling and construction solutions for residential<br> and commercial properties.'),
(2, 'crownproject4.jpg', 'We are professional for building construction', 'We have provided complete remodeling and construction solutions for <br>residential and commercial properties in cities.'),
(3, 'crownproject3.jpg', 'We will be happy to take care', 'We have provided complete remodeling and construction solutions for <br>residential and commercial properties in cities.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
