<?php include 'header.php'; ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Contact</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Contact</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Contact Section -->
    <section id="contact" class="contact section" style="background-color: black;color: white">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-6">
            <div class="info-item d-flex flex-column justify-content-center align-items-center" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-geo-alt"></i>
              <h3>Address</h3>
              <p>Office No. 208, 2nd Floor, Iconic Business Center, Opp. Imtiaz Express, BMCHS, Bahadurbad, Karachi, Pakistan</p>
            </div>
          </div><!-- End Info Item -->

          <div class="col-lg-3 col-md-6">
            <div class="info-item d-flex flex-column justify-content-center align-items-center" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-telephone"></i>
              <h3>Call Us</h3>
              <p>
(021) 111 127 696</p>
            </div>
          </div><!-- End Info Item -->

          <div class="col-lg-3 col-md-6">
            <div class="info-item d-flex flex-column justify-content-center align-items-center" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-envelope"></i>
              <h3>Email Us</h3>
              <p>thecrownbuilders786@gmail.com</p>
            </div>
          </div><!-- End Info Item -->

        </div>

        <div class="row gy-4 mt-1">
          <div class="col-lg-5" data-aos="fade-up" data-aos-delay="300">
           <iframe src="https://www.google.com/maps/embed?pb=!1m30!1m12!1m3!1d57916.06118373553!2d67.0019320504722!3d24.872256147660725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m15!3e0!4m3!3m2!1d24.8578048!2d67.0203904!4m3!3m2!1d24.886295399999998!2d67.06656579999999!4m5!1s0x3eb33fe2ab4f465b%3A0x521a02d924e2a973!2sIconic%20business%20center%2C%20Basement%20Plot%20%23%20247%2C%20Iconic%20Business%20Centre%2C%20opposite%20Imtiaz%20Express%2C%20Bahadurabad%20Karachi%2C%20Pakistan!3m2!1d24.886405999999997!2d67.066497!5e0!3m2!1sen!2s!4v1719606900898!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div><!-- End Google Maps -->
          <div class="col-md-1">
            
          </div>
          <div class="col-lg-6">
            <div class="container">
              <form  method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="400">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Your Name" required="">
                </div>

                <div class="col-md-6 ">
                  <input type="text" class="form-control" name="phone" placeholder="Your phone" required="">
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="subject" placeholder="Subject" required="">
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required=""></textarea>
                </div>

                <div class="col-md-12 text-center">
                 
                 <input type="submit" name="submit">
                </div>

              </div>
            </form>
            </div>
          </div><!-- End Contact Form -->

        </div>

      </div>

    </section><!-- /Contact Section -->

  </main>

 <?php 

include 'footer.php';
  ?>