<?php 
include 'header.php';
 ?>
  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section">

      <div class="info d-flex align-items-center">
        <div class="container">
          <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="100">
            <div class="col-lg-6 text-center">
              <h2>Welcome to The Crown builiders</h2>
              <p>The Crown Builders stands as a beacon of excellence in construction, with a three-decade legacy of delivering superior quality and craftsmanship. Specializing in residential, commercial, and landmark projects, we blend innovative design with meticulous attention to detail. Our commitment to exceeding industry standards and shaping communities defines us as leaders in the construction industry.</p>
              <a href="#get-started" class="btn-get-started" style="background-color: black;">Get Started</a>
            </div>
          </div>
        </div>
      </div>

      <div id="hero-carousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="5000">

       <!--  <div class="carousel-item">
          <img src="assets/img/hero-carousel/hero-carousel-1.jpg" alt="">
        </div> -->

        <div class="carousel-item active">
          <img src="assets/img/hero-carousel/hero-carousel-2.jpg" alt="">
        </div>

       <!--  <div class="carousel-item">
          <img src="assets/img/hero-carousel/hero-carousel-3.jpg" alt="">
        </div> -->

       <!--  <div class="carousel-item">
          <img src="assets/img/hero-carousel/hero-carousel-4.jpg" alt="">
        </div>

        <div class="carousel-item">
          <img src="assets/img/hero-carousel/hero-carousel-5.jpg" alt="">
        </div> -->

        <!-- <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a> -->

      </div>

    </section><!-- /Hero Section -->

    <!-- Get Started Section -->
  
    <!-- /Get Started Section -->

    <!-- Constructions Section -->
    <section id="constructions" class="constructions section" style="background-color: black;color: white;">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Constructions</h2>
        <p>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="assets/img/constructions-1.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title"> Residential Construction</h4>
                    <p>"Expert home building and renovations. We bring your vision to life with quality and attention to detail, tailored to your needs and budget."</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="assets/img/constructions-2.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Commercial Construction</h4>
                    <p>"High-quality solutions for offices, retail, and industrial spaces. From design to final inspection, we ensure smooth and timely project completion."</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="assets/img/constructions-3.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Sustainable Building</h4>
                    <p>"Eco-friendly construction using green technologies and materials. Our sustainable practices reduce environmental impact and enhance energy efficiency."</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div class="card-item">
              <div class="row">
                <div class="col-xl-5">
                  <div class="card-bg"><img src="assets/img/constructions-4.jpg" alt=""></div>
                </div>
                <div class="col-xl-7 d-flex align-items-center">
                  <div class="card-body">
                    <h4 class="card-title">Project Management</h4>
                    <p>"Flawless execution with expert planning and coordination. We keep you informed and ensure projects are completed on time and within budget."</p>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- End Card Item -->

        </div>

      </div>

    </section><!-- /Constructions Section -->

    <!-- Services Section -->
    <section id="services" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Services</h2>
        <p>We provide comprehensive construction services, from initial design <br>and planning to final project delivery, ensuring excellence at every step.</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="service-item  position-relative">
              <div class="icon">
                <i class="fa-solid fa-mountain-city"></i>
              </div>
              <h3>PRECISION FABRICATION</h3>
              <p>We specialize in precision fabrication, ensuring that every component is crafted with meticulous attention to detail. Utilizing the latest technology and skilled craftsmanship, we produce construction materials that meet exact specifications and deliver superior performance..</p>
             <!--  <a href="#" class="readmore stretched-link">Read more <i class="bi bi-arrow-right"></i></a> -->
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="fa-solid fa-arrow-up-from-ground-water"></i>
              </div>
              <h3>INNOVATIVE CONSTRUCTION</h3>
              <p>We excel in innovative construction, combining cutting-edge techniques with creative solutions to deliver outstanding results. Our team is dedicated to pushing the boundaries of what is possible, ensuring that each project is not only functional but also forward-thinking and sustainable.</p>
              <!-- <a href="#" class="readmore stretched-link">Read more <i class="bi bi-arrow-right"></i></a> -->
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="fa-solid fa-compass-drafting"></i>
              </div>
              <h3>PROJECT MANAGEMENT</h3>
              <p>We offer robust project management services, ensuring that every phase of the construction process is executed smoothly and efficiently. Our experienced project managers coordinate all aspects of the project, from budgeting and scheduling to resource allocation and risk management, ensuring timely and cost-effective completion.</p>
              
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="fa-solid fa-trowel-bricks"></i>
              </div>
              <h3>QUALITY CONTROL</h3>
              <p>We implement stringent quality control measures throughout every stage of our construction projects. Our dedicated quality assurance team conducts regular inspections and tests to ensure that all materials and workmanship meet the highest standards of excellence, guaranteeing a durable and reliable final product.</p>
             <!--  <a href="#" class="readmore stretched-link">Read more <i class="bi bi-arrow-right"></i></a> -->
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="fa-solid fa-helmet-safety"></i>
              </div>
              <h3>DESIGN AND PLANNING</h3>
              <p>Our expert team provides comprehensive design and planning services, tailored to meet the specific requirements of each project. We utilize the latest design software and methodologies to create innovative, efficient, and aesthetically pleasing solutions that align with our clients' visions and goals.</p>
            <!--   <a href="#" class="readmore stretched-link">Read more <i class="bi bi-arrow-right"></i></a> -->
            </div>
          </div><!-- End Service Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="service-item position-relative">
              <div class="icon">
                <i class="fa-solid fa-arrow-up-from-ground-water"></i>
              </div>
              <h3>CONSTRUCTION</h3>
              <p>We deliver excellence in building. Employing advanced techniques, our projects adhere to the highest quality standards. From initial planning to final execution, we ensure every detail is managed with utmost care, guaranteeing a successful and timely completion of each project.</p>
              <!-- <a href="#" class="readmore stretched-link">Read more <i class="bi bi-arrow-right"></i></a> -->
            </div>
          </div><!-- End Service Item -->

        </div>

      </div>

    </section><!-- /Services Section -->

    <!-- Alt Services Section -->
    <section id="alt-services" class="alt-services section" style="background-color: black;color: white">

      <div class="container">

        <div class="row justify-content-around gy-4">
          <div class="features-image col-lg-6" data-aos="fade-up" data-aos-delay="100"><img src="assets/img/alt-services.jpg" alt=""></div>

          <div class="col-lg-5 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
            <h3>COMMERCIAL, RESIDENTIAL, AND INDUSTRIAL CONSTRUCTION</h3>
            <p>We excel in constructing diverse projects including commercial buildings, residential properties, and industrial facilities. Our expertise ensures each structure is meticulously planned and executed to meet the highest standards of functionality, sustainability, and aesthetic appeal.</p>

            <div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-easel flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">SUSTAINABLE</a></h4>
                <p>We use eco-friendly materials and methods to create environmentally responsible projects</p>
              </div>
            </div><!-- End Icon Box -->

            <div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-patch-check flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">RENOVATION</a></h4>
                <p>We revitalize existing structures, improving functionality and aesthetics.</p>
              </div>
            </div><!-- End Icon Box -->

            <div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="500">
              <i class="bi bi-brightness-high flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">INFRASTRUCTURE</a></h4>
                <p>We develop robust solutions for transportation, utilities, and public facilities.</p>
              </div>
            </div><!-- End Icon Box -->

            <div class="icon-box d-flex position-relative" data-aos="fade-up" data-aos-delay="600">
              <i class="bi bi-brightness-high flex-shrink-0"></i>
              <div>
                <h4><a href="" class="stretched-link">Tride clov</a></h4>
                <p>Est voluptatem labore deleniti quis a delectus et. Saepe dolorem libero sit non aspernatur odit amet. Et eligendi</p>
              </div>
            </div><!-- End Icon Box -->

          </div>
        </div>

      </div>

    </section><!-- /Alt Services Section -->

    <!-- Features Section -->
   <!-- /Features Section -->

    <!-- Projects Section -->
    <section id="projects" class="projects section" style="background-color: black;color: white">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Projects</h2>
        <p>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>
      </div><!-- End Section Title -->
      <div class="container">
    <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">

        <ul class="portfolio-filters isotope-filters" data-aos="fade-up" data-aos-delay="100">
            <li data-filter="*" class="filter-active">All</li>
            <li data-filter=".filter-booking">BOOKING</li>
            <li data-filter=".filter-ongoing">Ongoing</li>
            <li data-filter=".filter-accomplish">Accomplish</li>
           <!--  <li data-filter=".filter-design">Design</li> -->
        </ul><!-- End Portfolio Filters -->

        <div class="row gy-4 isotope-container" data-aos="fade-up" data-aos-delay="200">

            <?php
            // Initial SQL query to fetch all projects ordered by id descending
            $q = "SELECT * FROM `projects` ORDER BY `id` DESC";
            $run = mysqli_query($con, $q);

            while ($data = mysqli_fetch_assoc($run)) {
                // Determine the appropriate filter class based on project status
                $filterClass = '';
                switch ($data['status']) {
                    case 'booking':
                        $filterClass = 'filter-booking';
                        break;
                    case 'ongoing':
                        $filterClass = 'filter-ongoing';
                        break;
                    case 'accomplish':
                        $filterClass = 'filter-accomplish';
                        break;
                    case 'Design':
                        $filterClass = 'filter-design';
                        break;
                    default:
                        $filterClass = '';
                        break;
                }
            ?>
                <div class="col-lg-4 col-md-6 portfolio-item isotope-item <?php echo $filterClass; ?>">
                    <div class="portfolio-content h-100">
                        <img src="Admin_panel/projectimages/<?php echo $data['image']; ?>" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><?php echo $data['title']; ?></h4>

                            <!-- Additional content like description, links, etc., can be added here -->
                        </div>


                    </div>
                     <a href="project_detail.php?id=<?php echo $data['id']; ?>">View</a>
                </div><!-- End Portfolio Item -->
            <?php } ?>

        </div><!-- End Portfolio Container -->

    </div>

</div>
<br><br>
<center>
    <button style="background-color: #ddad3e"><a href="projects.php" style="color: white;">VIEW More</a></button>
</center>



    </section><!-- /Projects Section -->

      <!-- Contact Section -->
    <section id="contact" class="contact section" style="background-color: black;color: white">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-6">
            <div class="info-item d-flex flex-column justify-content-center align-items-center" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-geo-alt"></i>
              <h3>Address</h3>
              <p>A108 Adam Street, New York, NY 535022</p>
            </div>
          </div><!-- End Info Item -->

          <div class="col-lg-3 col-md-6">
            <div class="info-item d-flex flex-column justify-content-center align-items-center" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-telephone"></i>
              <h3>Call Us</h3>
              <p>+1 5589 55488 55</p>
            </div>
          </div><!-- End Info Item -->

          <div class="col-lg-3 col-md-6">
            <div class="info-item d-flex flex-column justify-content-center align-items-center" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-envelope"></i>
              <h3>Email Us</h3>
              <p>info@example.com</p>
            </div>
          </div><!-- End Info Item -->

        </div>

        <div class="row gy-4 mt-1">
          <div class="col-lg-5" data-aos="fade-up" data-aos-delay="300">
           <iframe src="https://www.google.com/maps/embed?pb=!1m30!1m12!1m3!1d57916.06118373553!2d67.0019320504722!3d24.872256147660725!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m15!3e0!4m3!3m2!1d24.8578048!2d67.0203904!4m3!3m2!1d24.886295399999998!2d67.06656579999999!4m5!1s0x3eb33fe2ab4f465b%3A0x521a02d924e2a973!2sIconic%20business%20center%2C%20Basement%20Plot%20%23%20247%2C%20Iconic%20Business%20Centre%2C%20opposite%20Imtiaz%20Express%2C%20Bahadurabad%20Karachi%2C%20Pakistan!3m2!1d24.886405999999997!2d67.066497!5e0!3m2!1sen!2s!4v1719606900898!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div><!-- End Google Maps -->
          <div class="col-md-1">
            
          </div>
          <div class="col-lg-6">
            <div class="container">
              <form  method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="400">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" class="form-control" placeholder="Your Name" required="">
                </div>

                <div class="col-md-6 ">
                  <input type="text" class="form-control" name="phone" placeholder="Your phone" required="">
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="subject" placeholder="Subject" required="">
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required=""></textarea>
                </div>

                <div class="col-md-12 text-center">
                 
                 <input type="submit" name="submit">
                </div>

              </div>
            </form>
            </div>
          </div><!-- End Contact Form -->

        </div>

      </div>

    </section><!-- /Contact Section -->

  
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Validate the input
    if (!empty($name) && !empty($phone) && !empty($subject) && !empty($message)) {
        // Database connection settings
        $servername = "your_servername";
        $username = "your_username";
        $password = "your_password";
        $dbname = "your_database_name";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO contact_us (name, phone, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $phone, $subject, $message);

        // Execute the statement
        if ($stmt->execute()) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the connection
        $stmt->close();
        $conn->close();
    } else {
        echo "All fields are required.";
    }
} else {
    echo "Invalid request.";
}
?>

  </main>

<?php 
include 'footer.php';
 ?>