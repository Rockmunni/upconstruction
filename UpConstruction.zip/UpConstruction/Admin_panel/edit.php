<?php 
ob_start();
require_once "dp.php"; 
$id = $_GET['id'];

$q = "SELECT * FROM projects WHERE `id` = '$id'";
$run = mysqli_query($con, $q);
$data = mysqli_fetch_assoc($run);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Project</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg {
            background-color: black;
        }
        img {
            border-radius: 50px;
        }
        /* Hide toggle button on larger screens */
        @media (min-width: 768px) {
            .navbar-toggler {
                display: none;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light bg border-bottom-0">
        <!-- Navbar toggle button (hamburger icon) -->
        <button class="navbar-toggler d-block d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>
    <div class="offcanvas offcanvas-start bg d-md-block" tabindex="-1" id="sidebar" aria-labelledby="sidebarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-light" id="sidebarLabel">JUMANI BUILDERS</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active text-light" href="admin.php">Add-Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="projects.php">Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-none d-md-block bg-light sidebar">
                <div class="position-sticky vh-100 bg">
                    <div class="pt-3">
                        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                            <span class="text-light">JUMANI BUILDERS</span>
                        </h6>
                        <ul class="nav flex-column">
                           <li class="nav-item">
                    <a class="nav-link active text-light" href="admin.php">Add-Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="projects.php">Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="logout.php">Logout</a>
                </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="pt-3">
                    <h2 class="">Update Project</h2>
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($data['title']); ?>" placeholder="title" name="title">
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" placeholder="Description" name="description"><?php echo htmlspecialchars($data['description']); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="dp1">Image 01</label>
                            <img src="projectimages/<?php echo $data['image']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp1">
                        </div>
                        <div class="form-group">
                            <label for="dp2">Image 02</label>
                            <img src="projectimages/<?php echo $data['image_02']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp2">
                        </div>
                        <div class="form-group">
                            <label for="dp3">Image 03</label>
                            <img src="projectimages/<?php echo $data['image_03']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp3">
                        </div>
                        <div class="form-group">
                            <label for="dp4">Image 04</label>
                            <img src="projectimages/<?php echo $data['image_04']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp4">
                        </div>
                        <div class="form-group">
                            <label for="dp5">Image 05</label>
                            <img src="projectimages/<?php echo $data['image_05']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp5">
                        </div>
                        <div class="form-group">
                            <label for="dp6">Image 06</label>
                            <img src="projectimages/<?php echo $data['image_06']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp6">
                        </div>
                        <div class="form-group">
                            <label for="dp7">Image 07</label>
                            <img src="projectimages/<?php echo $data['image_07']; ?>" width="100px">
                            <input type="file" class="form-control" name="dp7">
                        </div>
                        <br><br>
                        <input type="submit" name="submit" value="Update Project">
                    </form>
                </div>
            </main>
        </div>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $t = $_POST['title'];
    $d = $_POST['description'];

    // Directory where images will be saved
    $uploadDir = "projectimages/";

    // Initialize array to hold uploaded file names
    $fileNames = [];

    // Process each file input
    $fileInputs = ['dp1', 'dp2', 'dp3', 'dp4', 'dp5', 'dp6', 'dp7'];
    foreach ($fileInputs as $fileInput) {
        if (isset($_FILES[$fileInput]) && $_FILES[$fileInput]['error'] == UPLOAD_ERR_OK) {
            $imageName = basename($_FILES[$fileInput]['name']);
            $imageTmpName = $_FILES[$fileInput]['tmp_name'];
            $destination = $uploadDir . $imageName;

            if (move_uploaded_file($imageTmpName, $destination)) {
                $fileNames[$fileInput] = $imageName;
            } else {
                $fileNames[$fileInput] = null;
            }
        } else {
            $fileNames[$fileInput] = null;
        }
    }

    // Retrieve the current images from the database
    $query = "SELECT `image`, `image_02`, `image_03`, `image_04`, `image_05`, `image_06`, `image_07` FROM `projects` WHERE `id` = '$id'";
    $result = mysqli_query($con, $query);
    $currentImages = mysqli_fetch_assoc($result);

    // Construct query to update data
    $updateQuery = "UPDATE `projects` SET 
                    `title` = '$t', 
                    `description` = '$d',
                    `image` = '".($fileNames['dp1'] ?? $currentImages['image'])."',
                    `image_02` = '".($fileNames['dp2'] ?? $currentImages['image_02'])."',
                    `image_03` = '".($fileNames['dp3'] ?? $currentImages['image_03'])."',
                    `image_04` = '".($fileNames['dp4'] ?? $currentImages['image_04'])."',
                    `image_05` = '".($fileNames['dp5'] ?? $currentImages['image_05'])."',
                    `image_06` = '".($fileNames['dp6'] ?? $currentImages['image_06'])."',
                    `image_07` = '".($fileNames['dp7'] ?? $currentImages['image_07'])."'
                    WHERE `id` = '$id'";

    // Execute query
    if (mysqli_query($con, $updateQuery)) {
        echo "<script>window.location.href = 'projects.php';</script>";
    } else {
        echo "<h4>Error: " . mysqli_error($con) . "</h4>";
    }   

}
?>
