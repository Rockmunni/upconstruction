<?php 
include '../db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>THE CROWN</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: black;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      animation: fadeIn 1s ease-out;
    }
    .card-header {
      border-radius: 15px 15px 0 0;
      background-image: linear-gradient(to right, #ddad3e, #000000);
    }
    .btn-primary {
      background-image: linear-gradient(to right, #ddad3e, #000000);
      border: none;
    }
    .btn-primary:hover {
      background-image: linear-gradient(to right, #000000, #ddad3e);
    }
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes shake {
      0%, 100% {
        transform: translateX(0);
      }
      25% {
        transform: translateX(-5px);
      }
      75% {
        transform: translateX(5px);
      }
    }
    .shake {
      animation: shake 0.5s;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card">
          <!-- <div class="card-header text-white text-center">Contact Us</div> -->
          <div class="card-body">
            <form id="contactForm" method="POST">
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
              </div>
              <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password">
              </div>
              <button type="submit" class="btn btn-primary w-100" name="login">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById('contactForm').addEventListener('submit', function(event) {
      var form = event.target;
      var inputs = form.querySelectorAll('input, textarea');
      var valid = true;
      inputs.forEach(function(input) {
        if (!input.value) {
          input.classList.add('is-invalid');
          valid = false;
        } else {
          input.classList.remove('is-invalid');
        }
      });
      if (!valid) {
        event.preventDefault();
        form.classList.add('shake');
        setTimeout(function() {
          form.classList.remove('shake');
        }, 500);
      }
    });
  </script>
</body>
</html>
<?php 
if (isset($_POST['login'])) {
  $e = $_POST['email'];
  $p = $_POST['password'];

  $q = "SELECT * FROM `admin` WHERE `email` = '$e' AND `password` = '$p'";
  $run = mysqli_query($con, $q);
  $count = mysqli_num_rows($run);
  if ($count == 1) {
    $_SESSION['email'] = $e;
    header('Location: admin.php');
  } else {
    echo "<script>alert('Error: Invalid details');</script>";
  }
}
?>
