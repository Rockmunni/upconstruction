<?php 
require_once "dp.php"; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Left Sidebar Example</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.6/css/jquery.dataTables.min.css">

    <style>
    *{
        color: black;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 1rem;
    }
    th, td {
        padding: 0.5rem;
        border: 1px solid #ddd;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
    .bg {
        background-color: black;
    }
    /* Hide toggle button on larger screens */
    @media (min-width: 768px) {
        .navbar-toggler {
            display: none;
        }
    }
</style>
</head>
<body>
    <nav class="navbar navbar-light bg border-bottom-0">
        <!-- Navbar toggle button (hamburger icon) -->
        <button class="navbar-toggler d-block d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>
    <div class="offcanvas offcanvas-start bg d-md-block" tabindex="-1" id="sidebar" aria-labelledby="sidebarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-light" id="sidebarLabel">JUMANI BUILDERS</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active text-light" href="admin.php">Add-Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="projects.php">Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-none d-md-block bg-light sidebar">
                <div class="position-sticky vh-100 bg">
                    <div class="pt-3">
                        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                            <span class="text-light">JUMANI BUILDERS</span>
                        </h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active text-light" href="admin.php">Add-Proejcts</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="projects.php">PROJECTS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="pt-3">
                    <h2 class="">Projects</h2>
                    <?php 
                        $q = "select * from projects";
                        $run = mysqli_query($con,$q);
                     ?>
                    <table id="example" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>image_01</th>
                                <th>image_02</th>
                                <th>image_03</th>
                                <th>image_04</th>
                                <th>image_05</th>
                                <th>image_06</th>
                                <th>image_07</th>
                                <th>Title</th>
                                <th>description</th>
                                <th>Edit</th>
                                <th>Delete</th>
                                

                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                while ($row = mysqli_fetch_assoc($run)) {
                                    # code...
                                
                             ?>
                            <tr>
                                 <td><img src="projectimages/<?php echo  $row['image'] ?>" width="100px"></td>
                                 <td><img src="projectimages/<?php echo  $row['image_02'] ?>" width="100px"></td>
                                  <td><img src="projectimages/<?php echo  $row['image_03'] ?>" width="100px"></td>
                                  <td><img src="projectimages/<?php echo  $row['image_04'] ?>" width="100px"></td>
                                  <td><img src="projectimages/<?php echo  $row['image_05'] ?>" width="100px"></td>
                                  <td><img src="projectimages/<?php echo  $row['image_06'] ?>" width="100px"></td>
                                  <td><img src="projectimages/<?php echo  $row['image_07'] ?>" width="100px"></td>
                                <td><?php echo  $row['title'] ?></td>
                               <td style="white-space: nowrap; overflow: hidden;"><?php echo $row['description']; ?></td>




                              <td><a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>


                               <td><a href="edit.php?id=<?php echo $row['id']; ?>">Delete</a></td>
                               
                               
                            </tr>
                        <?php } ?>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>

                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                    <script src="https://cdn.datatables.net/1.11.6/js/jquery.dataTables.min.js"></script>
                    <script>
                        $(document).ready(function() {
                            $('#example').DataTable();
                        });
                    </script>
                </div>
            </main>
        </div>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

