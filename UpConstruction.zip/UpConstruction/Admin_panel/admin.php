<?php 
require_once "dp.php"; 

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THE CROWN</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .bg {
            background-color: black;
        }
        /* Hide toggle button on larger screens */
        @media (min-width: 768px) {
            .navbar-toggler {
                display: none;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-light bg border-bottom-0">
        <!-- Navbar toggle button (hamburger icon) -->
        <button class="navbar-toggler d-block d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>
    <div class="offcanvas offcanvas-start bg d-md-block" tabindex="-1" id="sidebar" aria-labelledby="sidebarLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title text-light" id="sidebarLabel">THE CROWN   BUILDERS</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
           <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active text-light" href="admin.php">Add-Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="projects.php">Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-light" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-none d-md-block bg-light sidebar">
                <div class="position-sticky vh-100 bg">
                    <div class="pt-3">
                        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                            <span class="text-light">THE CROWN</span>
                        </h6>
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active text-light" href="admin.php">Add-Projects</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="projects.php">PROJECTS</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-light" href="logout">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="pt-3">
                    <h2 class="">Add-Projects</h2>
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control" placeholder="title" name="title">
                        </div>
                        <div class="form-group">
                            <label for="Description">Description</label>
                            <input type="text" class="form-control" placeholder="Description" name="Description">
                        </div>
                        <div class="form-group">
                            <label for="dp1">Image 01 size should be:1000x665</label>
                            <input type="file" class="form-control" name="dp1">
                        </div>
                        <div class="form-group">
                            <label for="dp2">Image 02</label>
                            <input type="file" class="form-control" name="dp2">
                        </div>
                        <div class="form-group">
                            <label for="dp3">Image 03</label>
                            <input type="file" class="form-control" name="dp3">
                        </div>
                        <div class="form-group">
                            <label for="dp4">Image 04</label>
                            <input type="file" class="form-control" name="dp4">
                        </div>
                        <div class="form-group">
                            <label for="dp5">Image 05</label>
                            <input type="file" class="form-control" name="dp5">
                        </div>
                        <div class="form-group">
                            <label for="dp6">Image 06</label>
                            <input type="file" class="form-control" name="dp6">
                        </div>
                        <div class="form-group">
                            <label for="dp6">Image 07 size should be:1000x665</label>
                            <input type="file" class="form-control" name="dp7">
                        </div>
                        <br><br>
                        <input type="submit" name="submit">
                    </form>
                </div>
            </main>
        </div>
    </div>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
    $t = $_POST['title'];
    $d = $_POST['Description'];
    $s = $_POST['status'];

    // Directory where images will be saved
    $uploadDir = "projectimages/";

    // Initialize array to hold uploaded file names
    $fileNames = [];

    // Initialize error message variable
    $errorMessage = "";

    // Process each file input
    $fileInputs = ['dp1', 'dp2', 'dp3', 'dp4', 'dp5', 'dp6', 'dp7'];
    foreach ($fileInputs as $fileInput) {
        if (isset($_FILES[$fileInput]) && $_FILES[$fileInput]['error'] == UPLOAD_ERR_OK) {
            $imageName = basename($_FILES[$fileInput]['name']);
            $imageTmpName = $_FILES[$fileInput]['tmp_name'];
            $destination = $uploadDir . $imageName;

            // Check image dimensions
            list($width, $height) = getimagesize($imageTmpName);
            if ($width == 1000 && $height == 847) {
                // Check file size (max size in bytes)
                $maxFileSize = 2 * 1024 * 1024; // 2 MB
                if ($_FILES[$fileInput]['size'] <= $maxFileSize) {
                    if (move_uploaded_file($imageTmpName, $destination)) {
                        $fileNames[$fileInput] = $imageName;
                    } else {
                        $fileNames[$fileInput] = null;
                    }
                } else {
                    $errorMessage .= "Image size must be less than or equal to 2 MB.\\n";
                    // Handle error or skip file
                    $fileNames[$fileInput] = null;
                }
            } else {
                $errorMessage .= "Image dimensions must be 1000x847 pixels.\\n";
                // Handle error or skip file
                $fileNames[$fileInput] = null;
            }
        } else {
            $fileNames[$fileInput] = null;
        }
    }

    // Check if there are any errors
    if (!empty($errorMessage)) {
        echo "<script>alert('" . $errorMessage . "');</script>";
    } else {
        // Check if all images met the criteria
        if (count(array_filter($fileNames)) == count($fileInputs)) {
            // Construct query with placeholders for image names
            $q = "INSERT INTO `projects`(`title`, `description`, `status`, `image`, `image_02`, `image_03`, `image_04`, `image_05`, `image_06`, `image_07`) 
                  VALUES ('$t', '$d', '$s', 
                  '".$fileNames['dp1']."',
                  '".$fileNames['dp2']."',
                  '".$fileNames['dp3']."',
                  '".$fileNames['dp4']."',
                  '".$fileNames['dp5']."',
                  '".$fileNames['dp6']."',
                  '".$fileNames['dp7']."')";

            // Execute query
            if (mysqli_query($con, $q)) {
                echo "<script>alert('Project added successfully');</script>";
            } else {
                echo "<script>alert('Error: " . mysqli_error($con) . "');</script>";
            }
        } else {
            echo "<script>alert('Error: Not all images met the criteria. Project not added.');</script>";
        }
    }
}
?>

