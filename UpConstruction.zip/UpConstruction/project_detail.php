<?php include 'header.php'; ?>
<?php 
// Check if 'id' is set in the URL and sanitize it
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensures that the ID is an integer

    // SQL query to select the project with the given ID
    $q = "SELECT * FROM `projects` WHERE `id` = '$id'";
    $run = mysqli_query($con, $q);
?>
 <!-- Page Title -->
    <div class="page-title" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Project Details</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Project Details</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->



     <section id="blog-posts" class="blog-posts section">

      <div class="container">
         <?php $data = mysqli_fetch_assoc($run) ?>
        <div class="row gy-4">

          <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div><!-- End post list item -->
           <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image_02'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div>
           <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image_03'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div>
           <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image_04'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div>
           <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image_05'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div>
           <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image_06'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div>
           <div class="col-lg-4">
            <article class="position-relative h-100">

              <div class="post-img position-relative overflow-hidden">
                <img src="Admin_panel/projectimages/<?php echo $data['image_07'] ?>" class="img-fluid" alt="">
                
              </div>
            </article>
          </div>

        </div>
      </div>

    </section>
<!-- <div class="container-fluid" style="margin-top: 150px">
    <div class="row">
        <?php while ($data = mysqli_fetch_assoc($run)) { ?>
            <div class="col-lg-2">
                
            </div>
            <div class="col-lg-3">
           
            <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image']); ?>" class="img-fluid" alt="Project Image" width="100%">
               <br><br>
                <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_02']); ?>" class="img-fluid" alt="Project Image" width="100%">
               <br><br>
                <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_03']); ?>" class="img-fluid" alt="Project Image" width="100%">
               
            </div>
           
             <div class="col-lg-3">
           
            <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_04']); ?>" class="img-fluid" alt="Project Image" width="100%">
               <br><br>
                <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_05']); ?>" class="img-fluid" alt="Project Image" width="100%">
               <br><br>
                <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_06']); ?>" class="img-fluid" alt="Project Image" width="100%">
               
            </div>
             <div class="col-lg-2">
                
            </div>
             <!-- <div class="col-lg-4">
            <h1><b><?php echo htmlspecialchars($data['title']); ?></b></h1>
            <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image']); ?>" class="img-fluid" alt="Project Image" width="100%">
               <br><br>
                <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_02']); ?>" class="img-fluid" alt="Project Image" width="100%">
               <br><br>
                <img src="admin_panel/projectimages/<?php echo htmlspecialchars($data['image_03']); ?>" class="img-fluid" alt="Project Image" width="100%">
               
            </div> -->

             
        <?php } ?>
    </div>
</div>
<?php 
} else {
    echo "<p>Invalid project ID.</p>";
}
?> -->
<br><br><br>
<?php include 'footer.php'; ?>
